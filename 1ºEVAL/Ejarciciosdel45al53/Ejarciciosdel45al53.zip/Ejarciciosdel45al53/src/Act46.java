public class Act46 {

    public static void main(String[] args) {
/*Realizar un algoritmo que permita leer tres números para después ordenarlos de mayor a
menor o de menor a mayor. El tipo de ordenación se le pedirá al usuario, pudiendo este
volver a introducir nuevos datos sin tener que volver a ejecutar el algoritmo.*/


    }

}
