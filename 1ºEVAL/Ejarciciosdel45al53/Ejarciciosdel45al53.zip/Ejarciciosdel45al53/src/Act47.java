import java.util.Scanner;

public class Act47 {

    public static void main(String[] args) {

        final double tarifa_normal=8;
        double horas_trabajadas;
        final double pago_extra=(1.5*tarifa_normal);
        final double libre_imp=600;
        final double[] impuestos = {0.25,0.45};
        final double impuesto_25= 1000;
        final double tarifa_normal_max_horas=35;
        double salario_sinExtras;
        double salario_bruto;
        double salario_extra=0;
        double impuesto_total;
        double salario_neto;

        Scanner sc=new Scanner(System.in);

        System.out.println("Introduce las horas trabajadas esta semana segun tus registros de entrada/salida");
        horas_trabajadas=sc.nextDouble();
        if (horas_trabajadas>=tarifa_normal_max_horas){
        salario_sinExtras=tarifa_normal_max_horas*tarifa_normal;
        if(horas_trabajadas>tarifa_normal_max_horas) {
            salario_extra = ((horas_trabajadas -tarifa_normal_max_horas)*pago_extra);
        }
        }else{

            salario_sinExtras=horas_trabajadas*tarifa_normal;

        }

        salario_bruto=salario_extra+salario_sinExtras;
        if (salario_bruto>libre_imp){

            if (salario_bruto<impuesto_25){

                impuesto_total=salario_bruto*impuestos[0];

            }else{



            }

        }



    }

}
